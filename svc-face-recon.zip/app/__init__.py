# app/__init__.py
# Torna o diretório um pacote Python.
__all__ = []
