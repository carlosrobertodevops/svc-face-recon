# app/repository.py
import time
import psycopg
from psycopg.rows import dict_row
from app.settings import settings


def get_conn(retries: int = 5, delay: int = 3):
    """
    Estabelece conexão resiliente com o PostgreSQL.
    Tenta reconectar automaticamente caso o serviço ainda esteja subindo.
    """
    for attempt in range(1, retries + 1):
        try:
            conn = psycopg.connect(
                settings.DATABASE_URL, autocommit=True, row_factory=dict_row
            )
            if attempt > 1:
                print(
                    f"[INFO] Conexão restabelecida com sucesso após {attempt} tentativas."
                )
            return conn
        except psycopg.OperationalError as e:
            print(
                f"[WARN] Falha na tentativa {attempt}/{retries} de conexão ao banco: {e}"
            )
            time.sleep(delay)
        except Exception as e:
            print(f"[ERROR] Erro inesperado ao tentar conectar ao banco: {e}")
            time.sleep(delay)

    raise Exception(
        "[ERROR] Não foi possível conectar ao banco após múltiplas tentativas."
    )


def fetch_all_embeddings():
    """
    Busca todos os embeddings existentes na tabela 'embeddings'.
    Retorna uma lista de tuplas (member_id, embedding_bytes).
    """
    try:
        with get_conn() as conn, conn.cursor() as cur:
            cur.execute("SELECT member_id, embedding FROM embeddings;")
            rows = cur.fetchall()
            print(f"[INFO] {len(rows)} embeddings carregados do banco.")
            return rows
    except psycopg.OperationalError as e:
        print(f"[ERROR] Falha ao buscar embeddings (problema de conexão): {e}")
        return []
    except Exception as e:
        print(f"[ERROR] Falha inesperada ao buscar embeddings: {e}")
        return []


def save_embedding(member_id: int, embedding_bytes: bytes):
    """
    Insere ou atualiza um único embedding no banco.
    """
    try:
        with get_conn() as conn, conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO embeddings (member_id, embedding)
                VALUES (%s, %s)
                ON CONFLICT (member_id)
                DO UPDATE SET embedding = EXCLUDED.embedding;
                """,
                (member_id, embedding_bytes),
            )
            print(f"[INFO] Embedding salvo/atualizado para membro {member_id}.")
    except psycopg.OperationalError as e:
        print(f"[ERROR] Falha de conexão ao salvar embedding de {member_id}: {e}")
    except Exception as e:
        print(f"[ERROR] Erro inesperado ao salvar embedding de {member_id}: {e}")


def delete_embedding(member_id: int):
    """
    Remove um embedding específico do banco.
    """
    try:
        with get_conn() as conn, conn.cursor() as cur:
            cur.execute("DELETE FROM embeddings WHERE member_id = %s;", (member_id,))
            print(f"[INFO] Embedding removido para membro {member_id}.")
    except Exception as e:
        print(f"[ERROR] Falha ao remover embedding {member_id}: {e}")


# from typing import Optional, Union
# import numpy as np
# import psycopg
# from .config import settings


# def get_conn():
#     return psycopg.connect(settings.DATABASE_URL)


# def upsert_member_embedding(member_id: Union[int, str], embedding: np.ndarray) -> None:
#     with get_conn() as conn, conn.cursor() as cur:
#         cur.execute(
#             """
#             insert into member_faces (member_id, embedding)
#             values (%s, %s)
#             on conflict (member_id)
#             do update set embedding = excluded.embedding, updated_at = now();
#             """,
#             (int(member_id), embedding.tolist()),
#         )


# def fetch_all_embeddings() -> list[tuple[str, np.ndarray]]:
#     out = []
#     with get_conn() as conn, conn.cursor() as cur:
#         cur.execute("select member_id, embedding from member_faces;")
#         for mid, emb in cur.fetchall():
#             out.append((str(int(mid)), np.array(emb, dtype=np.float32)))
#     return out


# def search_top1(embedding: np.ndarray) -> Optional[tuple[str, float]]:
#     """
#     Busca aproximada no pgvector usando distância de cosseno.
#     Retorna (member_id, distance) ou None.
#     """
#     with get_conn() as conn, conn.cursor() as cur:
#         cur.execute(
#             """
#             select member_id,
#                    1 - (embedding <#> %s) as cosine_similarity
#             from member_faces
#             order by embedding <#> %s
#             limit 1;
#             """,
#             (embedding.tolist(), embedding.tolist()),
#         )
#         row = cur.fetchone()
#         if not row:
#             return None
#         found_id, sim = row
#         dist = 1.0 - float(sim)
#         return (str(found_id), dist)
